package solutions.part4_5.java12_13;

import java.util.Arrays;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise4_String_Transform
{
	public static void main(String[] args) {
		
		var csvText = "HELLO,WORKSHOP,PARTICIPANTS,!,LET'S,HAVE,FUN";
		
		// Aufgabe 4a
		var allLowerCaseNoCommas = csvText.transform(String::toLowerCase)
				                          .transform(str -> str.replace(",", " "));
		System.out.println(allLowerCaseNoCommas);

		
		// Aufgabe 4b
		var asSingleValues = csvText.transform(String::toLowerCase)
				                    .transform(str -> str.contains("hello") ? str.replace("hello", "GRÜEZI") : str)
                                    .transform(str -> str.split(","));
		System.out.println(Arrays.asList(asSingleValues));	
	}
}
