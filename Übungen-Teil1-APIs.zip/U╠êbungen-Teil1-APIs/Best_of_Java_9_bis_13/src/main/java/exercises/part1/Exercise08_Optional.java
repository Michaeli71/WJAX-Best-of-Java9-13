package exercises.part1;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise08_Optional {

	public static void main(String[] args) 
	{
		final Optional<String> optName = Optional.of("Michael");
		final String result = badStyleExtractValue(optName);
		System.out.println(result);
		
		final Optional<String> optEmpty = Optional.empty();
		final String result2 = badStyleExtractValue(optEmpty);
		System.out.println(result2);
		
		final Stream<String> nameStream = asStream(optName);
		final String result3 = nameStream.filter(str -> str.startsWith("X")).findFirst().orElse("Not Found");
		System.out.println(result3);
	}

	static <T> T badStyleExtractValue(final Optional<T> opt)
	{
		T value = opt.get();
		return value;
	}
	
	static <T> Stream<T> asStream(final Optional<T> opt)
	{
		if (!opt.isPresent())
		{
			return Stream.empty();
		}
		
		return Stream.of(opt.get());
	}
}
